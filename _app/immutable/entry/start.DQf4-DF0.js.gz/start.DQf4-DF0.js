import{a as r}from"../chunks/BmR7P9tS.js";import{v as t}from"../chunks/Coogc8iR.js";export{t as load_css,r as start};
