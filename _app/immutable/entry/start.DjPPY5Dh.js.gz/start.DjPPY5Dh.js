import{a as r}from"../chunks/C34AlSrL.js";import{y as t}from"../chunks/CjKgzbIM.js";export{t as load_css,r as start};
