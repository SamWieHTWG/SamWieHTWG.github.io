import{a as r}from"../chunks/DnSFm56y.js";import{y as t}from"../chunks/DbhtpNJn.js";export{t as load_css,r as start};
