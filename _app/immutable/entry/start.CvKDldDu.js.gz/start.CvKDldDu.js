import{a as r}from"../chunks/D7abgW7J.js";import{v as t}from"../chunks/CCDpoyGx.js";export{t as load_css,r as start};
