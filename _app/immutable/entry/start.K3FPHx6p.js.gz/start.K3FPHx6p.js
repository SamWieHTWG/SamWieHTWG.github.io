import{a as r}from"../chunks/D0m1UC2t.js";import{A as t}from"../chunks/gSBl-7HV.js";export{t as load_css,r as start};
