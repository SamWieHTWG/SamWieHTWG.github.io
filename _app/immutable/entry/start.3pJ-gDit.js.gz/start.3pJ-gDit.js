import{a as r}from"../chunks/3cVdpuN2.js";import{y as t}from"../chunks/BOI0WAx2.js";export{t as load_css,r as start};
