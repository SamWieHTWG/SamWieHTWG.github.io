import{a as r}from"../chunks/CwPBCwOU.js";import{y as t}from"../chunks/DaSegAdh.js";export{t as load_css,r as start};
