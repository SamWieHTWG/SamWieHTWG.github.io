import{a as r}from"../chunks/CWxu99Lg.js";import{y as t}from"../chunks/1JpAZMUF.js";export{t as load_css,r as start};
