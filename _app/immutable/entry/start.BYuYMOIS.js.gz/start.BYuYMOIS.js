import{a as r}from"../chunks/B2qWiGh4.js";import{v as t}from"../chunks/Cn8HAYVA.js";export{t as load_css,r as start};
