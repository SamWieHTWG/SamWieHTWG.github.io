import{a as r}from"../chunks/DzT8FX6S.js";import{y as t}from"../chunks/IwjpoHZ8.js";export{t as load_css,r as start};
