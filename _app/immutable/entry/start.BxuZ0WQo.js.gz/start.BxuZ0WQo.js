import{a as r}from"../chunks/XdRTVCBD.js";import{y as t}from"../chunks/PmYMAqmr.js";export{t as load_css,r as start};
