import{a as r}from"../chunks/BN6w-i-T.js";import{y as t}from"../chunks/B1V--xDm.js";export{t as load_css,r as start};
