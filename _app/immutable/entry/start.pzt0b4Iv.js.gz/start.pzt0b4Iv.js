import{a as r}from"../chunks/BRm1vDHm.js";import{y as t}from"../chunks/D4O4QX4J.js";export{t as load_css,r as start};
