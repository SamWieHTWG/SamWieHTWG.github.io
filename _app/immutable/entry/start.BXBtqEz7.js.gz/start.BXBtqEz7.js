import{a as r}from"../chunks/CjRG_9EK.js";import{y as t}from"../chunks/D7E8zgWL.js";export{t as load_css,r as start};
