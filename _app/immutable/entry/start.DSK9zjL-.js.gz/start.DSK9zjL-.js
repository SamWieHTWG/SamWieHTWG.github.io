import{a as r}from"../chunks/EVDHJf4k.js";import{y as t}from"../chunks/BP2r60g7.js";export{t as load_css,r as start};
