import{a as r}from"../chunks/BoThKyEB.js";import{y as t}from"../chunks/C_p0LmCO.js";export{t as load_css,r as start};
