import{a as r}from"../chunks/CUX5oiVL.js";import{v as t}from"../chunks/BTM_ddiV.js";export{t as load_css,r as start};
