import{a as r}from"../chunks/CaSjH2bv.js";import{v as t}from"../chunks/DBrdaujU.js";export{t as load_css,r as start};
