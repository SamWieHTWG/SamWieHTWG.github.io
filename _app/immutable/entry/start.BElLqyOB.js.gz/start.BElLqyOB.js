import{a as r}from"../chunks/bVtxX2bV.js";import{y as t}from"../chunks/D51cp4pO.js";export{t as load_css,r as start};
