import{a as r}from"../chunks/_Z4RtmNw.js";import{x as t}from"../chunks/D6Lk9Ql4.js";export{t as load_css,r as start};
