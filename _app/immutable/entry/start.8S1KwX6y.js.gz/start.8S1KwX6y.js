import{a as r}from"../chunks/BDHKlXsU.js";import{A as t}from"../chunks/DLKPkES9.js";export{t as load_css,r as start};
