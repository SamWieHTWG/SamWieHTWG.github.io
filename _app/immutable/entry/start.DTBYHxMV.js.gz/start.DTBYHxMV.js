import{a as r}from"../chunks/BeMtPtvV.js";import{y as t}from"../chunks/CD6GW8m4.js";export{t as load_css,r as start};
