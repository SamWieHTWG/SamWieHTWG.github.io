import{a as r}from"../chunks/J-NNcffn.js";import{y as t}from"../chunks/CDdnL9Ui.js";export{t as load_css,r as start};
