import{a as r}from"../chunks/Cq1kGngg.js";import{y as t}from"../chunks/zgxFSiCm.js";export{t as load_css,r as start};
