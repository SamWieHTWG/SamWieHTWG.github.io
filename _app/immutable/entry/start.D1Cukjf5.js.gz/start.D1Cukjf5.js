import{a as r}from"../chunks/CAbHLcdU.js";import{y as t}from"../chunks/-aWXrnBz.js";export{t as load_css,r as start};
