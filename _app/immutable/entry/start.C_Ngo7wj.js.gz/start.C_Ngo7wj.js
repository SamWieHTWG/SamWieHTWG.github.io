import{a as r}from"../chunks/CF1SYlIn.js";import{y as t}from"../chunks/B5_JU8nc.js";export{t as load_css,r as start};
