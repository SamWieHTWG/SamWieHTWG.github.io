import{a as r}from"../chunks/BnRYaebf.js";import{y as t}from"../chunks/C4sS2T11.js";export{t as load_css,r as start};
