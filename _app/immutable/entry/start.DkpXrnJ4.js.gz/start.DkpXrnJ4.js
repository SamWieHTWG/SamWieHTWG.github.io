import{a as r}from"../chunks/CVH89Ods.js";import{v as t}from"../chunks/Db0jUvVj.js";export{t as load_css,r as start};
