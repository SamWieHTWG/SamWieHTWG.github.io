import{a as r}from"../chunks/b-4cZj7W.js";import{A as t}from"../chunks/BVIFmWNp.js";export{t as load_css,r as start};
