import{a as r}from"../chunks/CrYEm_2K.js";import{y as t}from"../chunks/CymU5GQd.js";export{t as load_css,r as start};
