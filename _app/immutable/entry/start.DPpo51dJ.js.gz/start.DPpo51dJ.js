import{a as r}from"../chunks/RrTC0Mcj.js";import{y as t}from"../chunks/CtIPYIVm.js";export{t as load_css,r as start};
