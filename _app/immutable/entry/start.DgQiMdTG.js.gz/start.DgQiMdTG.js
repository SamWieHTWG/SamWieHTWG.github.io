import{a as r}from"../chunks/B8yXBdMf.js";import{y as t}from"../chunks/DvJMpHqR.js";export{t as load_css,r as start};
