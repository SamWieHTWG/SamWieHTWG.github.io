import{a as r}from"../chunks/B6OotOEb.js";import{y as t}from"../chunks/w3GiAqv0.js";export{t as load_css,r as start};
