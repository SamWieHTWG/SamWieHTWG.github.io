import{a as r}from"../chunks/DTH76jTS.js";import{y as t}from"../chunks/BqEQFg1R.js";export{t as load_css,r as start};
