import{a as r}from"../chunks/BD31yxCX.js";import{y as t}from"../chunks/7G3l7oLv.js";export{t as load_css,r as start};
