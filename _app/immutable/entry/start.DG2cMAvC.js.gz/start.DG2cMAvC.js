import{a as r}from"../chunks/ZbYRy-Dy.js";import{y as t}from"../chunks/D1E2swLJ.js";export{t as load_css,r as start};
