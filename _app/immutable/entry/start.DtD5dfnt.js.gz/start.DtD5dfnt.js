import{a as r}from"../chunks/Cd5AUO_E.js";import{v as t}from"../chunks/ByCT-M8V.js";export{t as load_css,r as start};
