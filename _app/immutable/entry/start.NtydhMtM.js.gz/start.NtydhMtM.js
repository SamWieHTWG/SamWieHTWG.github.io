import{a as r}from"../chunks/DLD6iaDV.js";import{y as t}from"../chunks/Ynq54ipz.js";export{t as load_css,r as start};
