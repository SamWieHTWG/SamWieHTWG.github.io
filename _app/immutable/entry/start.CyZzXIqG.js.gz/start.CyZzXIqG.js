import{a as r}from"../chunks/Byfjt_n0.js";import{y as t}from"../chunks/CeajK3Gh.js";export{t as load_css,r as start};
