import{a as r}from"../chunks/dBjkuh6O.js";import{y as t}from"../chunks/BGc9rqPE.js";export{t as load_css,r as start};
