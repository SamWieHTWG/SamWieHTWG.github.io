import{a as r}from"../chunks/BJxYFSAA.js";import{y as t}from"../chunks/Cd9kGfaD.js";export{t as load_css,r as start};
