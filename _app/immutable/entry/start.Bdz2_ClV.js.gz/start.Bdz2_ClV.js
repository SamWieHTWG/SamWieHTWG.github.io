import{a as r}from"../chunks/BxhyIN-a.js";import{A as t}from"../chunks/DgGSOQXX.js";export{t as load_css,r as start};
