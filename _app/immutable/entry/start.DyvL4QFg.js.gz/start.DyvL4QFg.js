import{a as r}from"../chunks/CQZgXgme.js";import{v as t}from"../chunks/BR9XSesW.js";export{t as load_css,r as start};
