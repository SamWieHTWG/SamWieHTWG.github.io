import{a as r}from"../chunks/CiI7UTPU.js";import{y as t}from"../chunks/cr_3_DCm.js";export{t as load_css,r as start};
