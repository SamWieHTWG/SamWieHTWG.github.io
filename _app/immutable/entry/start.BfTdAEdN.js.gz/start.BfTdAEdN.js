import{a as r}from"../chunks/BqcbSIPc.js";import{y as t}from"../chunks/BOFSTtfN.js";export{t as load_css,r as start};
