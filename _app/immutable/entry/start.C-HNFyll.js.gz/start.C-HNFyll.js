import{a as r}from"../chunks/CHVzYg3L.js";import{A as t}from"../chunks/CMaaihqG.js";export{t as load_css,r as start};
