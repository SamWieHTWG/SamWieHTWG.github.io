import{a as r}from"../chunks/BKz3loJW.js";import{y as t}from"../chunks/C_06vxrA.js";export{t as load_css,r as start};
