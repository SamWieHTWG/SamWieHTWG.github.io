import{a as r}from"../chunks/CBFP4DCh.js";import{y as t}from"../chunks/CRMrPxNF.js";export{t as load_css,r as start};
