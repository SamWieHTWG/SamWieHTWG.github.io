import{a as r}from"../chunks/ChQSzY__.js";import{y as t}from"../chunks/CpD7xhiW.js";export{t as load_css,r as start};
