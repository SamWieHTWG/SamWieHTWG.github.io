import{a as r}from"../chunks/CN5BdxEu.js";import{y as t}from"../chunks/B5VkO9TA.js";export{t as load_css,r as start};
