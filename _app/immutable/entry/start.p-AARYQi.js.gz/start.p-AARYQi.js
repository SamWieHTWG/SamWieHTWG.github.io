import{a as r}from"../chunks/CBShshZZ.js";import{y as t}from"../chunks/DeRsLVbw.js";export{t as load_css,r as start};
