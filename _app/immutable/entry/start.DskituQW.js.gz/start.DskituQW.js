import{a as r}from"../chunks/BlWkDULb.js";import{y as t}from"../chunks/nXkeitml.js";export{t as load_css,r as start};
