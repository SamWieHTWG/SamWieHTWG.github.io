import{a as r}from"../chunks/CDjSi5G6.js";import{v as t}from"../chunks/BcDB6lXS.js";export{t as load_css,r as start};
