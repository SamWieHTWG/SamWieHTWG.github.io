import{a as r}from"../chunks/B14JmIM4.js";import{y as t}from"../chunks/CpA1Oz1i.js";export{t as load_css,r as start};
