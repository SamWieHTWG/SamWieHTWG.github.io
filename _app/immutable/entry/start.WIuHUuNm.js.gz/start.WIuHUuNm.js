import{l as o,a as r}from"../chunks/BR_d3f4Z.js";export{o as load_css,r as start};
