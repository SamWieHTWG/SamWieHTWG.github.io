import{a as r}from"../chunks/IJrHmOfo.js";import{v as t}from"../chunks/6d6grf-N.js";export{t as load_css,r as start};
