const e=()=>({}),r=Object.freeze(Object.defineProperty({__proto__:null,load:e,prerender:!0,ssr:!1},Symbol.toStringTag,{value:"Module"}));export{r as universal};
