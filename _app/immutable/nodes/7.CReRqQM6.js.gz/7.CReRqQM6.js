import{b as e,_ as n}from"../chunks/BePkJauO.js";export{e as component,n as universal};
