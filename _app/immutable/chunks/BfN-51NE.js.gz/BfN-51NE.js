import{i as a}from"./BuFjotJ2.js";a();
