import{R as o}from"./CYgJF_JY.js";import"./D6Lk9Ql4.js";function n(r,t){throw new o(r,t.toString())}export{n as r};
