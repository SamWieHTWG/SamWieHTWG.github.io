import"./CWj6FrbW.js";import"./L2DJem1u.js";import{F as k,ah as h,G as E,D as dt,ai as Tt,O as st,P as K,I as mt,J as L,K as C,t as G,M as ut,L as D,av as wt,ax as Et,aj as I,A as m,w as A,ak as z,al as xt,y as F,az as bt,a4 as vt,ap as Pt,am as kt}from"./Cqp8bxVM.js";import{l as $,p as x,i as O,s as Lt}from"./B2332r9h.js";import{a as Y,C as Z,i as gt,b as J,s as pt,e as Ct}from"./BITwWVFN.js";import{_ as yt}from"./Dp1pzeXC.js";import{c as ht,b as St}from"./BKVNmyoH.js";import"./BbzIG6HC.js";import{b as Ht,s as j,G as Mt,R as Rt,a as X}from"./DRJdUWNT.js";import{b as p,C as zt,s as Ft}from"./DPHjEBEl.js";var At=k("<span></span>");function Dt(i,t){const l=$(t,["children","$$slots","$$events","$$legacy"]),n=$(l,["size"]);let a=x(t,"size",8,"default");var e=At();Y(e,r=>({...n,[Z]:r}),[()=>({"bx--tag":!0,"bx--tag--sm":a()==="sm","bx--skeleton":!0})]),h("click",e,function(r){p.call(this,t,r)}),h("mouseover",e,function(r){p.call(this,t,r)}),h("mouseenter",e,function(r){p.call(this,t,r)}),h("mouseleave",e,function(r){p.call(this,t,r)}),E(i,e)}var Nt=k("<span> </span>"),It=k('<div><!> <button type="button"><!></button></div>'),Ot=k("<div><!></div>"),Gt=k("<button><!> <span><!></span></button>"),Bt=k("<div><!></div>"),Ut=k("<div><!> <span><!></span></div>");function qt(i,t){const l=Ht(t),n=$(t,["children","$$slots","$$events","$$legacy"]),a=$(n,["type","size","filter","disabled","interactive","skeleton","title","icon","id"]);dt(t,!1);let e=x(t,"type",8,void 0),r=x(t,"size",8,"default"),c=x(t,"filter",8,!1),o=x(t,"disabled",8,!1),g=x(t,"interactive",8,!1),b=x(t,"skeleton",8,!1),v=x(t,"title",8,"Clear filter"),u=x(t,"icon",8,void 0),T=x(t,"id",24,()=>"ccs-"+Math.random().toString(36));const N=Tt();gt();var V=st(),ft=K(V);{var Q=S=>{Dt(S,Lt({get size(){return r()}},()=>a,{$$events:{click(P){p.call(this,t,P)},mouseover(P){p.call(this,t,P)},mouseenter(P){p.call(this,t,P)},mouseleave(P){p.call(this,t,P)}}}))},W=(S,P)=>{{var tt=R=>{var y=It();Y(y,s=>({"aria-label":v(),id:T(),...a,[Z]:s}),[()=>({"bx--tag":!0,"bx--tag--disabled":o(),"bx--tag--filter":c(),"bx--tag--sm":r()==="sm","bx--tag--red":e()==="red","bx--tag--magenta":e()==="magenta","bx--tag--purple":e()==="purple","bx--tag--blue":e()==="blue","bx--tag--cyan":e()==="cyan","bx--tag--teal":e()==="teal","bx--tag--green":e()==="green","bx--tag--gray":e()==="gray","bx--tag--cool-gray":e()==="cool-gray","bx--tag--warm-gray":e()==="warm-gray","bx--tag--high-contrast":e()==="high-contrast","bx--tag--outline":e()==="outline"})]);var H=L(y);j(H,t,"default",{props:{class:"bx--tag__label"}},s=>{var w=Nt();J(w,1,"",null,{},{"bx--tag__label":!0});var B=L(w,!0);C(w),G(()=>ut(B,e())),E(s,w)});var f=D(H,2);J(f,1,"",null,{},{"bx--tag__close-icon":!0});var _=L(f);zt(_,{}),C(f),C(y),G(()=>{pt(f,"aria-labelledby",T()),f.disabled=o(),pt(f,"title",v())}),h("click",f,function(s){p.call(this,t,s)}),h("click",f,Ft(()=>{N("close")})),h("mouseover",f,function(s){p.call(this,t,s)}),h("mouseenter",f,function(s){p.call(this,t,s)}),h("mouseleave",f,function(s){p.call(this,t,s)}),E(R,y)},et=(R,y)=>{{var H=_=>{var s=Gt();Y(s,d=>({type:"button",id:T(),disabled:o(),"aria-disabled":o(),tabindex:o()?"-1":void 0,...a,[Z]:d}),[()=>({"bx--tag":!0,"bx--tag--interactive":!0,"bx--tag--disabled":o(),"bx--tag--sm":r()==="sm","bx--tag--red":e()==="red","bx--tag--magenta":e()==="magenta","bx--tag--purple":e()==="purple","bx--tag--blue":e()==="blue","bx--tag--cyan":e()==="cyan","bx--tag--teal":e()==="teal","bx--tag--green":e()==="green","bx--tag--gray":e()==="gray","bx--tag--cool-gray":e()==="cool-gray","bx--tag--warm-gray":e()==="warm-gray","bx--tag--high-contrast":e()==="high-contrast","bx--tag--outline":e()==="outline"})]);var w=L(s);{var B=d=>{var M=Ot();J(M,1,"",null,{},{"bx--tag__custom-icon":!0});var lt=L(M);j(lt,t,"icon",{},nt=>{var q=st(),rt=K(q);ht(rt,u,(ot,it)=>{it(ot,{})}),E(nt,q)}),C(M),E(d,M)};O(w,d=>{(l.icon||u())&&d(B)})}var U=D(w,2),at=L(U);j(at,t,"default",{},null),C(U),C(s),h("click",s,function(d){p.call(this,t,d)}),h("mouseover",s,function(d){p.call(this,t,d)}),h("mouseenter",s,function(d){p.call(this,t,d)}),h("mouseleave",s,function(d){p.call(this,t,d)}),E(_,s)},f=_=>{var s=Ut();Y(s,d=>({id:T(),...a,[Z]:d}),[()=>({"bx--tag":!0,"bx--tag--disabled":o(),"bx--tag--sm":r()==="sm","bx--tag--red":e()==="red","bx--tag--magenta":e()==="magenta","bx--tag--purple":e()==="purple","bx--tag--blue":e()==="blue","bx--tag--cyan":e()==="cyan","bx--tag--teal":e()==="teal","bx--tag--green":e()==="green","bx--tag--gray":e()==="gray","bx--tag--cool-gray":e()==="cool-gray","bx--tag--warm-gray":e()==="warm-gray","bx--tag--high-contrast":e()==="high-contrast","bx--tag--outline":e()==="outline"})]);var w=L(s);{var B=d=>{var M=Bt();J(M,1,"",null,{},{"bx--tag__custom-icon":!0});var lt=L(M);j(lt,t,"icon",{},nt=>{var q=st(),rt=K(q);ht(rt,u,(ot,it)=>{it(ot,{})}),E(nt,q)}),C(M),E(d,M)};O(w,d=>{(l.icon||u())&&d(B)})}var U=D(w,2),at=L(U);j(at,t,"default",{},null),C(U),C(s),h("click",s,function(d){p.call(this,t,d)}),h("mouseover",s,function(d){p.call(this,t,d)}),h("mouseenter",s,function(d){p.call(this,t,d)}),h("mouseleave",s,function(d){p.call(this,t,d)}),E(_,s)};O(R,_=>{g()?_(H):_(f,!1)},y)}};O(S,R=>{c()?R(tt):R(et,!1)},P)}};O(ft,S=>{b()?S(Q):S(W,!1)})}E(i,V),mt()}var jt=k('<span class="svelte-13x9acq"></span>');function ct(i,t){dt(t,!1);let l=x(t,"formula",8),n=x(t,"padding",8,null),a=A(),e=0;async function r(){if(!m(a)||!l())return;const g=++e;try{const{render:b}=await yt(async()=>{const{render:v}=await import("./D8Do4g9D.js");return{render:v}},[],import.meta.url);if(g!==e||!m(a))return;bt(a,m(a).innerHTML=""),b(l(),m(a),{throwOnError:!1,displayMode:!1})}catch(b){console.error("KaTeX rendering error:",b),m(a)&&bt(a,m(a).textContent=l())}}wt(async()=>{await Et(),r()}),I(()=>(z(l()),m(a)),()=>{l()&&m(a)&&r()}),xt(),gt();var c=jt();let o;St(c,g=>F(a,g),()=>m(a)),G(()=>o=Ct(c,"",o,{padding:n()!==null?`${n()}px`:void 0})),E(i,c),mt()}var Jt=k("<!> ",1),Kt=k("<div><!></div>"),Vt=k("<!> <!> <!> <!>",1);function fe(i,t){dt(t,!1);const l=A(),n=A(),a=A();let e=x(t,"formula",8),r=x(t,"isFulfilled",8,null),c=x(t,"tagTextGood",8,null),o=x(t,"tagTextBad",8,null),g=x(t,"additionalSign1",8,""),b=A(),v=A(m(l)),u=A(!1);I(()=>z(e()),()=>{F(l,e().Result||"")}),I(()=>(z(c()),z(o())),()=>{F(n,c()!=null&&o()!=null)}),I(()=>z(r()),()=>{F(b,r()?"green":"red")}),I(()=>(z(r()),z(c()),z(o())),()=>{F(a,r()?c()||"":o()||"")}),I(()=>(m(l),m(v)),()=>{m(l)!==m(v)&&m(v)!==""&&(F(u,!0),setTimeout(()=>{F(u,!1)},500)),F(v,m(l))}),xt(),gt(),Mt(i,{fullWidth:!0,style:"padding: var(--cds-spacing-03);",children:(T,N)=>{Rt(T,{noGutterRight:!0,padding:!1,children:(V,ft)=>{var Q=Vt(),W=K(Q);X(W,{noGutterRight:!0,sm:2,md:2,lg:2,children:(y,H)=>{ct(y,{padding:0,get formula(){return e().Name}})},$$slots:{default:!0}});var S=D(W,2);X(S,{noGutterRight:!0,sm:2,md:2,lg:7,children:(y,H)=>{var f=Jt(),_=K(f);ct(_,{get formula(){return e().Abstract}});var s=D(_);G(()=>ut(s,` ${g()??""}`)),E(y,f)},$$slots:{default:!0}});var P=D(S,2);const tt=vt(()=>m(n)?3:7);X(P,{noGutterRight:!0,sm:2,md:2,get lg(){return m(tt)},children:(y,H)=>{var f=Kt();let _;var s=L(f);ct(s,{get formula(){return m(l)}}),C(f),G(w=>_=J(f,1,"svelte-u1m8dl",null,_,w),[()=>({highlighted:m(u)})],vt),E(y,f)},$$slots:{default:!0}});var et=D(P,2);{var R=y=>{X(y,{sm:2,md:2,lg:4,children:(H,f)=>{qt(H,{get type(){return m(b)},get title(){return m(a)},style:"margin-top: -3px;",children:(_,s)=>{Pt();var w=kt();G(()=>ut(w,m(a))),E(_,w)},$$slots:{default:!0}})},$$slots:{default:!0}})};O(et,y=>{m(n)&&y(R)})}E(V,Q)},$$slots:{default:!0}})},$$slots:{default:!0}}),mt()}const Qt={format:"A4",margin:{top:"20mm",bottom:"20mm",left:"15mm",right:"15mm"},printBackground:!0,displayHeaderFooter:!1,landscape:!1,scale:1};function _t(i){const t=document.createElement("div");t.innerHTML=i;const l=[];return t.querySelectorAll("h1, h2, h3, h4, h5, h6").forEach((a,e)=>{var g;const r=parseInt(a.tagName.charAt(1)),c=((g=a.textContent)==null?void 0:g.trim())||"";let o=a.id;o||(o=`heading-${e+1}`,a.id=o),c&&l.push({id:o,text:c,level:r,originalTag:a.tagName.toLowerCase()})}),t.innerHTML="",l}function Wt(i,t="Inhaltsverzeichnis"){if(i.length===0)return"";let l=`<div class="table-of-contents">
    <h2 class="toc-title">${t}</h2>
    <nav class="toc-nav">`,n=0;i.forEach((a,e)=>{if(a.level>n)for(let c=n;c<a.level;c++)l+='<ul class="toc-list">';else if(a.level<n)for(let c=a.level;c<n;c++)l+="</ul>";const r=a.pageNumber!==void 0?a.pageNumber.toString():"...";l+=`<li class="toc-item toc-level-${a.level}">
      <a href="#${a.id}" class="toc-link">
        <span class="toc-text">${a.text}</span>
        <span class="toc-dots"></span>
        <span class="toc-page-number">${r}</span>
      </a>
    </li>`,n=a.level});for(let a=0;a<n;a++)l+="</ul>";return l+="</nav></div>",l}function Xt(){const i=[];for(const t of Array.from(document.styleSheets))try{const l=t.cssRules||t.rules;l&&Array.from(l).forEach(n=>n.cssText&&i.push(n.cssText))}catch{t.href&&i.push(`@import url("${t.href}");`)}return document.querySelectorAll("style").forEach(t=>t.textContent&&i.push(t.textContent)),i.join(`
`)}async function Yt(i,t={}){const l=document.createElement("div");l.style.position="absolute",l.style.left="-9999px",l.style.top="-9999px",l.style.visibility="hidden",document.body.appendChild(l);try{const{mount:n,unmount:a}=await yt(async()=>{const{mount:u,unmount:T}=await import("./Cqp8bxVM.js").then(N=>N.bg);return{mount:u,unmount:T}},[],import.meta.url);await document.fonts.ready;const e=n(i,{target:l,props:t});await new Promise(u=>setTimeout(u,100));let r="",c=0;const o=20;for(let u=0;u<o;u++){const T=l.innerHTML;if(T===r){if(c++,c>=3)break}else c=0;r=T,await new Promise(N=>setTimeout(N,200))}const g=l.querySelectorAll("img");g.length>0&&await Promise.all(Array.from(g).map(u=>u.complete?Promise.resolve():new Promise(T=>{u.addEventListener("load",T),u.addEventListener("error",T),setTimeout(T,3e3)})));const b=l.innerHTML;if(a(e),!b.trim())throw new Error("Component rendered empty HTML");const v=Xt();return{html:b,styles:v}}finally{l.remove()}}async function Zt(i){const t=[];let l="",n="";for(const[a,e]of i.entries()){const{component:r,props:c={},title:o=`Page ${a+1}`}=e,{html:g,styles:b}=await Yt(r,c),v=o?`<div class="pdf-page">
           <h1 class="page-title" id="page-${a+1}">${o}</h1>
           ${g}
         </div>`:`<div class="pdf-page" id="page-${a+1}">${g}</div>`;t.push({title:o,html:v}),l+=v,a===0&&(n=b)}return{html:l,styles:n,pageInfo:t}}function $t(i){const t=window.location.origin;let l=i.replace(/url\(['"]?\/(fonts\/[^'"()]+)['"]?\)/g,`url('${t}/$1')`);return l+=`
    /* Fallback font rules for PDF generation */
    body, html, * {
      font-family: 'Quicksand', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif !important;
    }
  `,l}function te(i,t,l="Report",n={}){const a=n.calculationReportSubtitle||"Berechnungsbericht",e=$t(t);let r=i,c="";if(n.includeTableOfContents){const o=n.customTocEntries||_t(i);if(o.length>0&&(c=Wt(o,n.tocTitle),!n.customTocEntries)){const g=document.createElement("div");g.innerHTML=i,o.forEach(b=>{const v=g.querySelector(`#${b.id}`);v&&!v.id&&(v.id=b.id)}),r=g.innerHTML}}return`<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <title>${l}</title>
  <style>
    ${e}
    html, body { margin:0; padding:0; width:100%; background:white; }
    .pdf-header { text-align:center; margin-bottom:20px; }
    .pdf-content { width:100%; margin:8px; }
    button { display:none; }

    .table-of-contents {
      margin: 30px 0;
      padding: 20px 0;
      page-break-after: always;
    }

    .toc-title {
      margin: 0 0 20px 0;
      padding-bottom: 10px;
      border-bottom: 2px solid #333;
      font-size: 1.5em;
      color: #333;
    }

    .toc-nav {
      margin: 0;
    }

    .toc-list {
      list-style: none;
      margin: 0;
      padding: 0;
    }

    .toc-item {
      margin: 8px 0;
      line-height: 1.4;
    }

    .toc-link {
      display: flex;
      text-decoration: none;
      color: #333;
      padding: 4px 0;
      align-items: baseline;
    }

    .toc-link:hover {
      color: #0066cc;
    }

    .toc-text {
      flex-shrink: 0;
      margin-right: 8px;
    }

    .toc-dots {
      flex-grow: 1;
      border-bottom: 1px dotted #666;
      margin: 0 8px;
      height: 1px;
      margin-bottom: 4px;
    }

    .toc-page-number {
      flex-shrink: 0;
      font-style: italic;
      color: #666;
      min-width: 30px;
      text-align: right;
      font-weight: 500;
    }

    .toc-level-1 { margin-left: 0; }
    .toc-level-2 { margin-left: 20px; }
    .toc-level-3 { margin-left: 40px; }
    .toc-level-4 { margin-left: 60px; }
    .toc-level-5 { margin-left: 80px; }
    .toc-level-6 { margin-left: 100px; }

    .toc-level-2 .toc-text { font-size: 0.95em; }
    .toc-level-3 .toc-text { font-size: 0.9em; }
    .toc-level-4 .toc-text { font-size: 0.85em; }
    .toc-level-5 .toc-text { font-size: 0.8em; }
    .toc-level-6 .toc-text { font-size: 0.75em; }

    .pdf-page {
      page-break-before: always;
      margin-bottom: 30px;
      width: 100%;
    }

    .pdf-page:first-child {
      page-break-before: auto;
    }

    .page-title {
      margin-top: 0;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 2px solid #333;
      color: #333;
      font-size: 1.8em;
    }
  </style>
</head>
<body>
  <div class="pdf-header">
    ${n.headerHTML||`<h1>${l}</h1>
    <p>${a}</p>
    <p>Generiert am: ${new Date().toLocaleString("de-DE")}</p>`}
  </div>
  ${c}
  <div class="pdf-content">${r}</div>
</body>
</html>`}async function ee(i,t={},l="report.pdf"){let n;n="https://elastotool-pdf-server-126717118048.europe-west3.run.app";const a=await fetch(`${n}/generate-pdf`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({html:i,options:{...Qt,...t}})});if(!a.ok){const r=await a.text();throw new Error(`PDF generation failed: ${a.statusText} - ${r}`)}const e=await a.blob();if(!e.size)throw new Error("PDF returned empty file");return e}function ae(i,t){const l=URL.createObjectURL(i),n=document.createElement("a");n.href=l,n.download=t,document.body.appendChild(n),n.click(),URL.revokeObjectURL(l),n.remove()}function le(i,t,l="Brückenlager-Eingabeparameter",n="Berechnete Elastomer-Parameter"){const a=[];return i.forEach((e,r)=>{var b,v;const c=t[r],o=r+2;a.push({id:`page-${r+1}`,text:e.title||`Component ${r+1}`,level:1,originalTag:"h1",pageNumber:o}),(e.component.name==="PDFElastoParams"||(b=e.title)!=null&&b.includes("Elastomer-Parameter")||(v=e.title)!=null&&v.includes("Elastomer Parameters"))&&(a.push({id:"input-params",text:l,level:2,originalTag:"h3",pageNumber:o}),a.push({id:"calculated-params",text:n,level:2,originalTag:"h3",pageNumber:o})),_t(c.html).forEach(u=>{u.level>1&&u.id!=="input-params"&&u.id!=="calculated-params"&&a.push({id:`page-${r+1}-${u.id}`,text:u.text,level:Math.min(u.level+1,6),originalTag:u.originalTag,pageNumber:o})})}),a}async function be(i,t="multi-report",l={},n="statiqs Multi-Component Report",a){const{html:e,styles:r,pageInfo:c}=await Zt(i);let o;l.includeTableOfContents&&(o=le(i,c,l.inputParamsSectionTitle,l.calculatedParamsSectionTitle));const g=te(e,r,n,{includeTableOfContents:l.includeTableOfContents,tocTitle:l.tocTitle||"Inhaltsverzeichnis",customTocEntries:o,headerHTML:a,calculationReportSubtitle:l.calculationReportSubtitle}),b=await ee(g,l,`${t}.pdf`);ae(b,`${t}.pdf`)}export{fe as F,qt as T,ct as a,be as c};
