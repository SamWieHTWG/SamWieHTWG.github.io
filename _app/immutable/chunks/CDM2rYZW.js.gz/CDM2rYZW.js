import{j as a}from"./-MGJ8Q07.js";a();
