import{j as a}from"./K0MPNFwM.js";a();
