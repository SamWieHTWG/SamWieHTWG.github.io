import"./CWj6FrbW.js";import"./Ca6fLpEK.js";import{k as P,ai as h,o as E,p as dt,aj as Tt,y as st,z as J,q as mt,r as C,u as L,l as B,w as ut,v as D,ad as wt,af as Et,ak as O,i as m,m as A,al as R,am as xt,f as F,an as bt,T as vt,a7 as kt,ah as Pt}from"./CajaEDN1.js";import{l as $,p as x,i as I,s as Ct}from"./DYmgau6I.js";import{a as Y,C as Z,i as gt,b as V,s as pt,c as Lt}from"./BDxLDxar.js";import{_ as yt}from"./Dp1pzeXC.js";import{c as ht,b as Ht}from"./DxQK9NPi.js";import"./CNQs3Lj_.js";import{s as Mt,b as j,G as St,R as zt,a as X}from"./BCaQskAH.js";import{b as f,C as Rt,s as Ft}from"./BGT2HNxy.js";var At=P("<span></span>");function Dt(r,t){const a=$(t,["children","$$slots","$$events","$$legacy"]),l=$(a,["size"]);let n=x(t,"size",8,"default");var e=At();Y(e,o=>({...l,[Z]:o}),[()=>({"bx--tag":!0,"bx--tag--sm":n()==="sm","bx--skeleton":!0})]),h("click",e,function(o){f.call(this,t,o)}),h("mouseover",e,function(o){f.call(this,t,o)}),h("mouseenter",e,function(o){f.call(this,t,o)}),h("mouseleave",e,function(o){f.call(this,t,o)}),E(r,e)}var Nt=P("<span> </span>"),Ot=P('<div><!> <button type="button"><!></button></div>'),It=P("<div><!></div>"),Bt=P("<button><!> <span><!></span></button>"),Gt=P("<div><!></div>"),Ut=P("<div><!> <span><!></span></div>");function qt(r,t){const a=Mt(t),l=$(t,["children","$$slots","$$events","$$legacy"]),n=$(l,["type","size","filter","disabled","interactive","skeleton","title","icon","id"]);dt(t,!1);let e=x(t,"type",8,void 0),o=x(t,"size",8,"default"),c=x(t,"filter",8,!1),i=x(t,"disabled",8,!1),u=x(t,"interactive",8,!1),v=x(t,"skeleton",8,!1),p=x(t,"title",8,"Clear filter"),b=x(t,"icon",8,void 0),T=x(t,"id",24,()=>"ccs-"+Math.random().toString(36));const N=Tt();gt();var K=st(),ft=J(K);{var Q=H=>{Dt(H,Ct({get size(){return o()}},()=>n,{$$events:{click(k){f.call(this,t,k)},mouseover(k){f.call(this,t,k)},mouseenter(k){f.call(this,t,k)},mouseleave(k){f.call(this,t,k)}}}))},W=(H,k)=>{{var tt=z=>{var y=Ot();Y(y,s=>({"aria-label":p(),id:T(),...n,[Z]:s}),[()=>({"bx--tag":!0,"bx--tag--disabled":i(),"bx--tag--filter":c(),"bx--tag--sm":o()==="sm","bx--tag--red":e()==="red","bx--tag--magenta":e()==="magenta","bx--tag--purple":e()==="purple","bx--tag--blue":e()==="blue","bx--tag--cyan":e()==="cyan","bx--tag--teal":e()==="teal","bx--tag--green":e()==="green","bx--tag--gray":e()==="gray","bx--tag--cool-gray":e()==="cool-gray","bx--tag--warm-gray":e()==="warm-gray","bx--tag--high-contrast":e()==="high-contrast","bx--tag--outline":e()==="outline"})]);var M=C(y);j(M,t,"default",{props:{class:"bx--tag__label"}},s=>{var w=Nt();V(w,1,"",null,{},{"bx--tag__label":!0});var G=C(w,!0);L(w),B(()=>ut(G,e())),E(s,w)});var g=D(M,2);V(g,1,"",null,{},{"bx--tag__close-icon":!0});var _=C(g);Rt(_,{}),L(g),L(y),B(()=>{pt(g,"aria-labelledby",T()),g.disabled=i(),pt(g,"title",p())}),h("click",g,function(s){f.call(this,t,s)}),h("click",g,Ft(()=>{N("close")})),h("mouseover",g,function(s){f.call(this,t,s)}),h("mouseenter",g,function(s){f.call(this,t,s)}),h("mouseleave",g,function(s){f.call(this,t,s)}),E(z,y)},et=(z,y)=>{{var M=_=>{var s=Bt();Y(s,d=>({type:"button",id:T(),disabled:i(),"aria-disabled":i(),tabindex:i()?"-1":void 0,...n,[Z]:d}),[()=>({"bx--tag":!0,"bx--tag--interactive":!0,"bx--tag--disabled":i(),"bx--tag--sm":o()==="sm","bx--tag--red":e()==="red","bx--tag--magenta":e()==="magenta","bx--tag--purple":e()==="purple","bx--tag--blue":e()==="blue","bx--tag--cyan":e()==="cyan","bx--tag--teal":e()==="teal","bx--tag--green":e()==="green","bx--tag--gray":e()==="gray","bx--tag--cool-gray":e()==="cool-gray","bx--tag--warm-gray":e()==="warm-gray","bx--tag--high-contrast":e()==="high-contrast","bx--tag--outline":e()==="outline"})]);var w=C(s);{var G=d=>{var S=It();V(S,1,"",null,{},{"bx--tag__custom-icon":!0});var nt=C(S);j(nt,t,"icon",{},lt=>{var q=st(),ot=J(q);ht(ot,b,(rt,it)=>{it(rt,{})}),E(lt,q)}),L(S),E(d,S)};I(w,d=>{(a.icon||b())&&d(G)})}var U=D(w,2),at=C(U);j(at,t,"default",{},null),L(U),L(s),h("click",s,function(d){f.call(this,t,d)}),h("mouseover",s,function(d){f.call(this,t,d)}),h("mouseenter",s,function(d){f.call(this,t,d)}),h("mouseleave",s,function(d){f.call(this,t,d)}),E(_,s)},g=_=>{var s=Ut();Y(s,d=>({id:T(),...n,[Z]:d}),[()=>({"bx--tag":!0,"bx--tag--disabled":i(),"bx--tag--sm":o()==="sm","bx--tag--red":e()==="red","bx--tag--magenta":e()==="magenta","bx--tag--purple":e()==="purple","bx--tag--blue":e()==="blue","bx--tag--cyan":e()==="cyan","bx--tag--teal":e()==="teal","bx--tag--green":e()==="green","bx--tag--gray":e()==="gray","bx--tag--cool-gray":e()==="cool-gray","bx--tag--warm-gray":e()==="warm-gray","bx--tag--high-contrast":e()==="high-contrast","bx--tag--outline":e()==="outline"})]);var w=C(s);{var G=d=>{var S=Gt();V(S,1,"",null,{},{"bx--tag__custom-icon":!0});var nt=C(S);j(nt,t,"icon",{},lt=>{var q=st(),ot=J(q);ht(ot,b,(rt,it)=>{it(rt,{})}),E(lt,q)}),L(S),E(d,S)};I(w,d=>{(a.icon||b())&&d(G)})}var U=D(w,2),at=C(U);j(at,t,"default",{},null),L(U),L(s),h("click",s,function(d){f.call(this,t,d)}),h("mouseover",s,function(d){f.call(this,t,d)}),h("mouseenter",s,function(d){f.call(this,t,d)}),h("mouseleave",s,function(d){f.call(this,t,d)}),E(_,s)};I(z,_=>{u()?_(M):_(g,!1)},y)}};I(H,z=>{c()?z(tt):z(et,!1)},k)}};I(ft,H=>{v()?H(Q):H(W,!1)})}E(r,K),mt()}var jt=P('<span class="svelte-13x9acq"></span>');function ct(r,t){dt(t,!1);let a=x(t,"formula",8),l=x(t,"padding",8,null),n=A(),e=0;async function o(){if(!m(n)||!a())return;const u=++e;try{const{render:v}=await yt(async()=>{const{render:p}=await import("./D8Do4g9D.js");return{render:p}},[],import.meta.url);if(u!==e||!m(n))return;bt(n,m(n).innerHTML=""),v(a(),m(n),{throwOnError:!1,displayMode:!1})}catch(v){console.error("KaTeX rendering error:",v),m(n)&&bt(n,m(n).textContent=a())}}wt(async()=>{await Et(),o()}),O(()=>(R(a()),m(n)),()=>{a()&&m(n)&&o()}),xt(),gt();var c=jt();let i;Ht(c,u=>F(n,u),()=>m(n)),B(()=>i=Lt(c,"",i,{padding:l()!==null?`${l()}px`:void 0})),E(r,c),mt()}var Vt=P("<!> ",1),Jt=P("<div><!></div>"),Kt=P("<!> <!> <!> <!>",1);function fe(r,t){dt(t,!1);const a=A(),l=A(),n=A();let e=x(t,"formula",8),o=x(t,"isFulfilled",8,null),c=x(t,"tagTextGood",8,null),i=x(t,"tagTextBad",8,null),u=x(t,"additionalSign1",8,""),v=A(),p=A(m(a)),b=A(!1);O(()=>R(e()),()=>{F(a,e().Result||"")}),O(()=>(R(c()),R(i())),()=>{F(l,c()!=null&&i()!=null)}),O(()=>R(o()),()=>{F(v,o()?"green":"red")}),O(()=>(R(o()),R(c()),R(i())),()=>{F(n,o()?c()||"":i()||"")}),O(()=>(m(a),m(p)),()=>{m(a)!==m(p)&&m(p)!==""&&(F(b,!0),setTimeout(()=>{F(b,!1)},500)),F(p,m(a))}),xt(),gt(),St(r,{fullWidth:!0,style:"padding: var(--cds-spacing-03);",children:(T,N)=>{zt(T,{noGutterRight:!0,padding:!1,children:(K,ft)=>{var Q=Kt(),W=J(Q);X(W,{noGutterRight:!0,sm:2,md:2,lg:2,children:(y,M)=>{ct(y,{padding:0,get formula(){return e().Name}})},$$slots:{default:!0}});var H=D(W,2);X(H,{noGutterRight:!0,sm:2,md:2,lg:7,children:(y,M)=>{var g=Vt(),_=J(g);ct(_,{get formula(){return e().Abstract}});var s=D(_);B(()=>ut(s,` ${u()??""}`)),E(y,g)},$$slots:{default:!0}});var k=D(H,2);const tt=vt(()=>m(l)?3:7);X(k,{noGutterRight:!0,sm:2,md:2,get lg(){return m(tt)},children:(y,M)=>{var g=Jt();let _;var s=C(g);ct(s,{get formula(){return m(a)}}),L(g),B(w=>_=V(g,1,"svelte-u1m8dl",null,_,w),[()=>({highlighted:m(b)})],vt),E(y,g)},$$slots:{default:!0}});var et=D(k,2);{var z=y=>{X(y,{sm:2,md:2,lg:4,children:(M,g)=>{qt(M,{get type(){return m(v)},get title(){return m(n)},style:"margin-top: -3px;",children:(_,s)=>{kt();var w=Pt();B(()=>ut(w,m(n))),E(_,w)},$$slots:{default:!0}})},$$slots:{default:!0}})};I(et,y=>{m(l)&&y(z)})}E(K,Q)},$$slots:{default:!0}})},$$slots:{default:!0}}),mt()}const Qt={format:"A4",margin:{top:"20mm",bottom:"20mm",left:"15mm",right:"15mm"},printBackground:!0,displayHeaderFooter:!1,landscape:!1,scale:1};function _t(r){const t=document.createElement("div");t.innerHTML=r;const a=[];return t.querySelectorAll("h1, h2, h3, h4, h5, h6").forEach((n,e)=>{var u;const o=parseInt(n.tagName.charAt(1)),c=((u=n.textContent)==null?void 0:u.trim())||"";let i=n.id;i||(i=`heading-${e+1}`,n.id=i),c&&a.push({id:i,text:c,level:o,originalTag:n.tagName.toLowerCase()})}),t.innerHTML="",a}function Wt(r,t="Inhaltsverzeichnis"){if(r.length===0)return"";let a=`<div class="table-of-contents">
    <h2 class="toc-title">${t}</h2>
    <nav class="toc-nav">`,l=0;r.forEach((n,e)=>{if(n.level>l)for(let c=l;c<n.level;c++)a+='<ul class="toc-list">';else if(n.level<l)for(let c=n.level;c<l;c++)a+="</ul>";const o=n.pageNumber!==void 0?n.pageNumber.toString():"...";a+=`<li class="toc-item toc-level-${n.level}">
      <a href="#${n.id}" class="toc-link">
        <span class="toc-text">${n.text}</span>
        <span class="toc-dots"></span>
        <span class="toc-page-number">${o}</span>
      </a>
    </li>`,l=n.level});for(let n=0;n<l;n++)a+="</ul>";return a+="</nav></div>",a}function Xt(){const r=[];for(const t of Array.from(document.styleSheets))try{const a=t.cssRules||t.rules;a&&Array.from(a).forEach(l=>l.cssText&&r.push(l.cssText))}catch{t.href&&r.push(`@import url("${t.href}");`)}return document.querySelectorAll("style").forEach(t=>t.textContent&&r.push(t.textContent)),r.join(`
`)}async function Yt(r,t={}){const a=document.createElement("div");a.style.position="absolute",a.style.left="-9999px",a.style.top="-9999px",a.style.visibility="hidden",document.body.appendChild(a);try{const{mount:l,unmount:n}=await yt(async()=>{const{mount:b,unmount:T}=await import("./CajaEDN1.js").then(N=>N.bg);return{mount:b,unmount:T}},[],import.meta.url);await document.fonts.ready;const e=l(r,{target:a,props:t});await new Promise(b=>setTimeout(b,100));let o="",c=0;const i=20;for(let b=0;b<i;b++){const T=a.innerHTML;if(T===o){if(c++,c>=3)break}else c=0;o=T,await new Promise(N=>setTimeout(N,200))}const u=a.querySelectorAll("img");u.length>0&&await Promise.all(Array.from(u).map(b=>b.complete?Promise.resolve():new Promise(T=>{b.addEventListener("load",T),b.addEventListener("error",T),setTimeout(T,3e3)})));const v=a.innerHTML;if(n(e),!v.trim())throw new Error("Component rendered empty HTML");const p=Xt();return{html:v,styles:p}}finally{a.remove()}}async function Zt(r){const t=[];let a="",l="";for(const[n,e]of r.entries()){const{component:o,props:c={},title:i=`Page ${n+1}`}=e,{html:u,styles:v}=await Yt(o,c),p=i?`<div class="pdf-page">
           <h1 class="page-title" id="page-${n+1}">${i}</h1>
           ${u}
         </div>`:`<div class="pdf-page" id="page-${n+1}">${u}</div>`;t.push({title:i,html:p}),a+=p,n===0&&(l=v)}return{html:a,styles:l,pageInfo:t}}function $t(r){const t=window.location.origin;let a=r.replace(/url\(['"]?\/(fonts\/[^'"()]+)['"]?\)/g,`url('${t}/$1')`);return a+=`
    /* Fallback font rules for PDF generation */
    body, html, * {
      font-family: 'Quicksand', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif !important;
    }
  `,a}function te(r,t,a="Report",l={}){const n="Berechnungsbericht",e=$t(t);let o=r,c="";if(l.includeTableOfContents){const i=l.customTocEntries||_t(r);if(i.length>0&&(c=Wt(i,l.tocTitle),!l.customTocEntries)){const u=document.createElement("div");u.innerHTML=r,i.forEach(v=>{const p=u.querySelector(`#${v.id}`);p&&!p.id&&(p.id=v.id)}),o=u.innerHTML}}return`<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <title>${a}</title>
  <style>
    ${e}
    html, body { margin:0; padding:0; width:100%; background:white; }
    .pdf-header { text-align:center; margin-bottom:20px; }
    .pdf-content { width:100%; margin:8px; }
    button { display:none; }

    .table-of-contents {
      margin: 30px 0;
      padding: 20px 0;
      page-break-after: always;
    }

    .toc-title {
      margin: 0 0 20px 0;
      padding-bottom: 10px;
      border-bottom: 2px solid #333;
      font-size: 1.5em;
      color: #333;
    }

    .toc-nav {
      margin: 0;
    }

    .toc-list {
      list-style: none;
      margin: 0;
      padding: 0;
    }

    .toc-item {
      margin: 8px 0;
      line-height: 1.4;
    }

    .toc-link {
      display: flex;
      text-decoration: none;
      color: #333;
      padding: 4px 0;
      align-items: baseline;
    }

    .toc-link:hover {
      color: #0066cc;
    }

    .toc-text {
      flex-shrink: 0;
      margin-right: 8px;
    }

    .toc-dots {
      flex-grow: 1;
      border-bottom: 1px dotted #666;
      margin: 0 8px;
      height: 1px;
      margin-bottom: 4px;
    }

    .toc-page-number {
      flex-shrink: 0;
      font-style: italic;
      color: #666;
      min-width: 30px;
      text-align: right;
      font-weight: 500;
    }

    .toc-level-1 { margin-left: 0; }
    .toc-level-2 { margin-left: 20px; }
    .toc-level-3 { margin-left: 40px; }
    .toc-level-4 { margin-left: 60px; }
    .toc-level-5 { margin-left: 80px; }
    .toc-level-6 { margin-left: 100px; }

    .toc-level-2 .toc-text { font-size: 0.95em; }
    .toc-level-3 .toc-text { font-size: 0.9em; }
    .toc-level-4 .toc-text { font-size: 0.85em; }
    .toc-level-5 .toc-text { font-size: 0.8em; }
    .toc-level-6 .toc-text { font-size: 0.75em; }

    .pdf-page {
      page-break-before: always;
      margin-bottom: 30px;
      width: 100%;
    }

    .pdf-page:first-child {
      page-break-before: auto;
    }

    .page-title {
      margin-top: 0;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 2px solid #333;
      color: #333;
      font-size: 1.8em;
    }
  </style>
</head>
<body>
  <div class="pdf-header">
    ${l.headerHTML||`<h1>${a}</h1>
    <p>${n}</p>
    <p>Generiert am: ${new Date().toLocaleString("de-DE")}</p>`}
  </div>
  ${c}
  <div class="pdf-content">${o}</div>
</body>
</html>`}async function ee(r,t={},a="report.pdf"){let l;l="https://elastotool-pdf-server-126717118048.europe-west3.run.app";const n=await fetch(`${l}/generate-pdf`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({html:r,options:{...Qt,...t}})});if(!n.ok){const o=await n.text();throw new Error(`PDF generation failed: ${n.statusText} - ${o}`)}const e=await n.blob();if(!e.size)throw new Error("PDF returned empty file");return e}function ae(r,t){const a=URL.createObjectURL(r),l=document.createElement("a");l.href=a,l.download=t,document.body.appendChild(l),l.click(),URL.revokeObjectURL(a),l.remove()}function ne(r,t){const a=[];return r.forEach((l,n)=>{var i;const e=t[n],o=n+2;a.push({id:`page-${n+1}`,text:l.title||`Component ${n+1}`,level:1,originalTag:"h1",pageNumber:o}),(l.component.name==="PDFElastoParams"||(i=l.title)!=null&&i.includes("Elastomer-Parameter"))&&(a.push({id:"input-params",text:"Brückenlager-Eingabeparameter",level:2,originalTag:"h3",pageNumber:o}),a.push({id:"calculated-params",text:"Berechnete Elastomer-Parameter",level:2,originalTag:"h3",pageNumber:o})),_t(e.html).forEach(u=>{u.level>1&&u.id!=="input-params"&&u.id!=="calculated-params"&&a.push({id:`page-${n+1}-${u.id}`,text:u.text,level:Math.min(u.level+1,6),originalTag:u.originalTag,pageNumber:o})})}),a}async function be(r,t="multi-report",a={},l="statiqs Multi-Component Report",n){const{html:e,styles:o,pageInfo:c}=await Zt(r);let i;a.includeTableOfContents&&(i=ne(r,c));const u=te(e,o,l,{includeTableOfContents:a.includeTableOfContents,tocTitle:a.tocTitle||"Inhaltsverzeichnis",customTocEntries:i,headerHTML:n}),v=await ee(u,a,`${t}.pdf`);ae(v,`${t}.pdf`)}export{ct as F,qt as T,fe as a,be as c};
