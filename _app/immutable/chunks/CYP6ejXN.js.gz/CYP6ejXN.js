import{w as a}from"./B_J1m_EM.js";a();
