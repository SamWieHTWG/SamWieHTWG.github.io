import"./CWj6FrbW.js";import"./Ctil3IE4.js";import{k as P,ai as h,o as E,p as dt,aj as Tt,y as st,z as J,q as mt,r as C,u as L,l as B,w as ut,v as D,ad as wt,af as Et,ak as I,i as m,m as A,al as z,am as xt,f as F,an as bt,T as vt,a7 as kt,ah as Pt}from"./K0MPNFwM.js";import{l as $,p as x,i as O,s as Ct}from"./Chmn9iJc.js";import{a as Y,C as Z,i as gt,b as V,s as pt,c as Lt}from"./CTaIyRD8.js";import{_ as yt}from"./Dp1pzeXC.js";import{c as ht,b as St}from"./oKxMK-sE.js";import"./BLQtpC4N.js";import{s as Ht,b as j,G as Mt,R as Rt,a as X}from"./Co__8MVi.js";import{b as p,C as zt,s as Ft}from"./DdYSTbM7.js";var At=P("<span></span>");function Dt(i,t){const l=$(t,["children","$$slots","$$events","$$legacy"]),n=$(l,["size"]);let a=x(t,"size",8,"default");var e=At();Y(e,o=>({...n,[Z]:o}),[()=>({"bx--tag":!0,"bx--tag--sm":a()==="sm","bx--skeleton":!0})]),h("click",e,function(o){p.call(this,t,o)}),h("mouseover",e,function(o){p.call(this,t,o)}),h("mouseenter",e,function(o){p.call(this,t,o)}),h("mouseleave",e,function(o){p.call(this,t,o)}),E(i,e)}var Nt=P("<span> </span>"),It=P('<div><!> <button type="button"><!></button></div>'),Ot=P("<div><!></div>"),Bt=P("<button><!> <span><!></span></button>"),Gt=P("<div><!></div>"),Ut=P("<div><!> <span><!></span></div>");function qt(i,t){const l=Ht(t),n=$(t,["children","$$slots","$$events","$$legacy"]),a=$(n,["type","size","filter","disabled","interactive","skeleton","title","icon","id"]);dt(t,!1);let e=x(t,"type",8,void 0),o=x(t,"size",8,"default"),c=x(t,"filter",8,!1),r=x(t,"disabled",8,!1),g=x(t,"interactive",8,!1),b=x(t,"skeleton",8,!1),v=x(t,"title",8,"Clear filter"),u=x(t,"icon",8,void 0),T=x(t,"id",24,()=>"ccs-"+Math.random().toString(36));const N=Tt();gt();var K=st(),ft=J(K);{var Q=S=>{Dt(S,Ct({get size(){return o()}},()=>a,{$$events:{click(k){p.call(this,t,k)},mouseover(k){p.call(this,t,k)},mouseenter(k){p.call(this,t,k)},mouseleave(k){p.call(this,t,k)}}}))},W=(S,k)=>{{var tt=R=>{var y=It();Y(y,s=>({"aria-label":v(),id:T(),...a,[Z]:s}),[()=>({"bx--tag":!0,"bx--tag--disabled":r(),"bx--tag--filter":c(),"bx--tag--sm":o()==="sm","bx--tag--red":e()==="red","bx--tag--magenta":e()==="magenta","bx--tag--purple":e()==="purple","bx--tag--blue":e()==="blue","bx--tag--cyan":e()==="cyan","bx--tag--teal":e()==="teal","bx--tag--green":e()==="green","bx--tag--gray":e()==="gray","bx--tag--cool-gray":e()==="cool-gray","bx--tag--warm-gray":e()==="warm-gray","bx--tag--high-contrast":e()==="high-contrast","bx--tag--outline":e()==="outline"})]);var H=C(y);j(H,t,"default",{props:{class:"bx--tag__label"}},s=>{var w=Nt();V(w,1,"",null,{},{"bx--tag__label":!0});var G=C(w,!0);L(w),B(()=>ut(G,e())),E(s,w)});var f=D(H,2);V(f,1,"",null,{},{"bx--tag__close-icon":!0});var _=C(f);zt(_,{}),L(f),L(y),B(()=>{pt(f,"aria-labelledby",T()),f.disabled=r(),pt(f,"title",v())}),h("click",f,function(s){p.call(this,t,s)}),h("click",f,Ft(()=>{N("close")})),h("mouseover",f,function(s){p.call(this,t,s)}),h("mouseenter",f,function(s){p.call(this,t,s)}),h("mouseleave",f,function(s){p.call(this,t,s)}),E(R,y)},et=(R,y)=>{{var H=_=>{var s=Bt();Y(s,d=>({type:"button",id:T(),disabled:r(),"aria-disabled":r(),tabindex:r()?"-1":void 0,...a,[Z]:d}),[()=>({"bx--tag":!0,"bx--tag--interactive":!0,"bx--tag--disabled":r(),"bx--tag--sm":o()==="sm","bx--tag--red":e()==="red","bx--tag--magenta":e()==="magenta","bx--tag--purple":e()==="purple","bx--tag--blue":e()==="blue","bx--tag--cyan":e()==="cyan","bx--tag--teal":e()==="teal","bx--tag--green":e()==="green","bx--tag--gray":e()==="gray","bx--tag--cool-gray":e()==="cool-gray","bx--tag--warm-gray":e()==="warm-gray","bx--tag--high-contrast":e()==="high-contrast","bx--tag--outline":e()==="outline"})]);var w=C(s);{var G=d=>{var M=Ot();V(M,1,"",null,{},{"bx--tag__custom-icon":!0});var lt=C(M);j(lt,t,"icon",{},nt=>{var q=st(),ot=J(q);ht(ot,u,(rt,it)=>{it(rt,{})}),E(nt,q)}),L(M),E(d,M)};O(w,d=>{(l.icon||u())&&d(G)})}var U=D(w,2),at=C(U);j(at,t,"default",{},null),L(U),L(s),h("click",s,function(d){p.call(this,t,d)}),h("mouseover",s,function(d){p.call(this,t,d)}),h("mouseenter",s,function(d){p.call(this,t,d)}),h("mouseleave",s,function(d){p.call(this,t,d)}),E(_,s)},f=_=>{var s=Ut();Y(s,d=>({id:T(),...a,[Z]:d}),[()=>({"bx--tag":!0,"bx--tag--disabled":r(),"bx--tag--sm":o()==="sm","bx--tag--red":e()==="red","bx--tag--magenta":e()==="magenta","bx--tag--purple":e()==="purple","bx--tag--blue":e()==="blue","bx--tag--cyan":e()==="cyan","bx--tag--teal":e()==="teal","bx--tag--green":e()==="green","bx--tag--gray":e()==="gray","bx--tag--cool-gray":e()==="cool-gray","bx--tag--warm-gray":e()==="warm-gray","bx--tag--high-contrast":e()==="high-contrast","bx--tag--outline":e()==="outline"})]);var w=C(s);{var G=d=>{var M=Gt();V(M,1,"",null,{},{"bx--tag__custom-icon":!0});var lt=C(M);j(lt,t,"icon",{},nt=>{var q=st(),ot=J(q);ht(ot,u,(rt,it)=>{it(rt,{})}),E(nt,q)}),L(M),E(d,M)};O(w,d=>{(l.icon||u())&&d(G)})}var U=D(w,2),at=C(U);j(at,t,"default",{},null),L(U),L(s),h("click",s,function(d){p.call(this,t,d)}),h("mouseover",s,function(d){p.call(this,t,d)}),h("mouseenter",s,function(d){p.call(this,t,d)}),h("mouseleave",s,function(d){p.call(this,t,d)}),E(_,s)};O(R,_=>{g()?_(H):_(f,!1)},y)}};O(S,R=>{c()?R(tt):R(et,!1)},k)}};O(ft,S=>{b()?S(Q):S(W,!1)})}E(i,K),mt()}var jt=P('<span class="svelte-13x9acq"></span>');function ct(i,t){dt(t,!1);let l=x(t,"formula",8),n=x(t,"padding",8,null),a=A(),e=0;async function o(){if(!m(a)||!l())return;const g=++e;try{const{render:b}=await yt(async()=>{const{render:v}=await import("./D8Do4g9D.js");return{render:v}},[],import.meta.url);if(g!==e||!m(a))return;bt(a,m(a).innerHTML=""),b(l(),m(a),{throwOnError:!1,displayMode:!1})}catch(b){console.error("KaTeX rendering error:",b),m(a)&&bt(a,m(a).textContent=l())}}wt(async()=>{await Et(),o()}),I(()=>(z(l()),m(a)),()=>{l()&&m(a)&&o()}),xt(),gt();var c=jt();let r;St(c,g=>F(a,g),()=>m(a)),B(()=>r=Lt(c,"",r,{padding:n()!==null?`${n()}px`:void 0})),E(i,c),mt()}var Vt=P("<!> ",1),Jt=P("<div><!></div>"),Kt=P("<!> <!> <!> <!>",1);function fe(i,t){dt(t,!1);const l=A(),n=A(),a=A();let e=x(t,"formula",8),o=x(t,"isFulfilled",8,null),c=x(t,"tagTextGood",8,null),r=x(t,"tagTextBad",8,null),g=x(t,"additionalSign1",8,""),b=A(),v=A(m(l)),u=A(!1);I(()=>z(e()),()=>{F(l,e().Result||"")}),I(()=>(z(c()),z(r())),()=>{F(n,c()!=null&&r()!=null)}),I(()=>z(o()),()=>{F(b,o()?"green":"red")}),I(()=>(z(o()),z(c()),z(r())),()=>{F(a,o()?c()||"":r()||"")}),I(()=>(m(l),m(v)),()=>{m(l)!==m(v)&&m(v)!==""&&(F(u,!0),setTimeout(()=>{F(u,!1)},500)),F(v,m(l))}),xt(),gt(),Mt(i,{fullWidth:!0,style:"padding: var(--cds-spacing-03);",children:(T,N)=>{Rt(T,{noGutterRight:!0,padding:!1,children:(K,ft)=>{var Q=Kt(),W=J(Q);X(W,{noGutterRight:!0,sm:2,md:2,lg:2,children:(y,H)=>{ct(y,{padding:0,get formula(){return e().Name}})},$$slots:{default:!0}});var S=D(W,2);X(S,{noGutterRight:!0,sm:2,md:2,lg:7,children:(y,H)=>{var f=Vt(),_=J(f);ct(_,{get formula(){return e().Abstract}});var s=D(_);B(()=>ut(s,` ${g()??""}`)),E(y,f)},$$slots:{default:!0}});var k=D(S,2);const tt=vt(()=>m(n)?3:7);X(k,{noGutterRight:!0,sm:2,md:2,get lg(){return m(tt)},children:(y,H)=>{var f=Jt();let _;var s=C(f);ct(s,{get formula(){return m(l)}}),L(f),B(w=>_=V(f,1,"svelte-u1m8dl",null,_,w),[()=>({highlighted:m(u)})],vt),E(y,f)},$$slots:{default:!0}});var et=D(k,2);{var R=y=>{X(y,{sm:2,md:2,lg:4,children:(H,f)=>{qt(H,{get type(){return m(b)},get title(){return m(a)},style:"margin-top: -3px;",children:(_,s)=>{kt();var w=Pt();B(()=>ut(w,m(a))),E(_,w)},$$slots:{default:!0}})},$$slots:{default:!0}})};O(et,y=>{m(n)&&y(R)})}E(K,Q)},$$slots:{default:!0}})},$$slots:{default:!0}}),mt()}const Qt={format:"A4",margin:{top:"20mm",bottom:"20mm",left:"15mm",right:"15mm"},printBackground:!0,displayHeaderFooter:!1,landscape:!1,scale:1};function _t(i){const t=document.createElement("div");t.innerHTML=i;const l=[];return t.querySelectorAll("h1, h2, h3, h4, h5, h6").forEach((a,e)=>{var g;const o=parseInt(a.tagName.charAt(1)),c=((g=a.textContent)==null?void 0:g.trim())||"";let r=a.id;r||(r=`heading-${e+1}`,a.id=r),c&&l.push({id:r,text:c,level:o,originalTag:a.tagName.toLowerCase()})}),t.innerHTML="",l}function Wt(i,t="Inhaltsverzeichnis"){if(i.length===0)return"";let l=`<div class="table-of-contents">
    <h2 class="toc-title">${t}</h2>
    <nav class="toc-nav">`,n=0;i.forEach((a,e)=>{if(a.level>n)for(let c=n;c<a.level;c++)l+='<ul class="toc-list">';else if(a.level<n)for(let c=a.level;c<n;c++)l+="</ul>";const o=a.pageNumber!==void 0?a.pageNumber.toString():"...";l+=`<li class="toc-item toc-level-${a.level}">
      <a href="#${a.id}" class="toc-link">
        <span class="toc-text">${a.text}</span>
        <span class="toc-dots"></span>
        <span class="toc-page-number">${o}</span>
      </a>
    </li>`,n=a.level});for(let a=0;a<n;a++)l+="</ul>";return l+="</nav></div>",l}function Xt(){const i=[];for(const t of Array.from(document.styleSheets))try{const l=t.cssRules||t.rules;l&&Array.from(l).forEach(n=>n.cssText&&i.push(n.cssText))}catch{t.href&&i.push(`@import url("${t.href}");`)}return document.querySelectorAll("style").forEach(t=>t.textContent&&i.push(t.textContent)),i.join(`
`)}async function Yt(i,t={}){const l=document.createElement("div");l.style.position="absolute",l.style.left="-9999px",l.style.top="-9999px",l.style.visibility="hidden",document.body.appendChild(l);try{const{mount:n,unmount:a}=await yt(async()=>{const{mount:u,unmount:T}=await import("./K0MPNFwM.js").then(N=>N.bg);return{mount:u,unmount:T}},[],import.meta.url);await document.fonts.ready;const e=n(i,{target:l,props:t});await new Promise(u=>setTimeout(u,100));let o="",c=0;const r=20;for(let u=0;u<r;u++){const T=l.innerHTML;if(T===o){if(c++,c>=3)break}else c=0;o=T,await new Promise(N=>setTimeout(N,200))}const g=l.querySelectorAll("img");g.length>0&&await Promise.all(Array.from(g).map(u=>u.complete?Promise.resolve():new Promise(T=>{u.addEventListener("load",T),u.addEventListener("error",T),setTimeout(T,3e3)})));const b=l.innerHTML;if(a(e),!b.trim())throw new Error("Component rendered empty HTML");const v=Xt();return{html:b,styles:v}}finally{l.remove()}}async function Zt(i){const t=[];let l="",n="";for(const[a,e]of i.entries()){const{component:o,props:c={},title:r=`Page ${a+1}`}=e,{html:g,styles:b}=await Yt(o,c),v=r?`<div class="pdf-page">
           <h1 class="page-title" id="page-${a+1}">${r}</h1>
           ${g}
         </div>`:`<div class="pdf-page" id="page-${a+1}">${g}</div>`;t.push({title:r,html:v}),l+=v,a===0&&(n=b)}return{html:l,styles:n,pageInfo:t}}function $t(i){const t=window.location.origin;let l=i.replace(/url\(['"]?\/(fonts\/[^'"()]+)['"]?\)/g,`url('${t}/$1')`);return l+=`
    /* Fallback font rules for PDF generation */
    body, html, * {
      font-family: 'Quicksand', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif !important;
    }
  `,l}function te(i,t,l="Report",n={}){const a=n.calculationReportSubtitle||"Berechnungsbericht",e=$t(t);let o=i,c="";if(n.includeTableOfContents){const r=n.customTocEntries||_t(i);if(r.length>0&&(c=Wt(r,n.tocTitle),!n.customTocEntries)){const g=document.createElement("div");g.innerHTML=i,r.forEach(b=>{const v=g.querySelector(`#${b.id}`);v&&!v.id&&(v.id=b.id)}),o=g.innerHTML}}return`<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <title>${l}</title>
  <style>
    ${e}
    html, body { margin:0; padding:0; width:100%; background:white; }
    .pdf-header { text-align:center; margin-bottom:20px; }
    .pdf-content { width:100%; margin:8px; }
    button { display:none; }

    .table-of-contents {
      margin: 30px 0;
      padding: 20px 0;
      page-break-after: always;
    }

    .toc-title {
      margin: 0 0 20px 0;
      padding-bottom: 10px;
      border-bottom: 2px solid #333;
      font-size: 1.5em;
      color: #333;
    }

    .toc-nav {
      margin: 0;
    }

    .toc-list {
      list-style: none;
      margin: 0;
      padding: 0;
    }

    .toc-item {
      margin: 8px 0;
      line-height: 1.4;
    }

    .toc-link {
      display: flex;
      text-decoration: none;
      color: #333;
      padding: 4px 0;
      align-items: baseline;
    }

    .toc-link:hover {
      color: #0066cc;
    }

    .toc-text {
      flex-shrink: 0;
      margin-right: 8px;
    }

    .toc-dots {
      flex-grow: 1;
      border-bottom: 1px dotted #666;
      margin: 0 8px;
      height: 1px;
      margin-bottom: 4px;
    }

    .toc-page-number {
      flex-shrink: 0;
      font-style: italic;
      color: #666;
      min-width: 30px;
      text-align: right;
      font-weight: 500;
    }

    .toc-level-1 { margin-left: 0; }
    .toc-level-2 { margin-left: 20px; }
    .toc-level-3 { margin-left: 40px; }
    .toc-level-4 { margin-left: 60px; }
    .toc-level-5 { margin-left: 80px; }
    .toc-level-6 { margin-left: 100px; }

    .toc-level-2 .toc-text { font-size: 0.95em; }
    .toc-level-3 .toc-text { font-size: 0.9em; }
    .toc-level-4 .toc-text { font-size: 0.85em; }
    .toc-level-5 .toc-text { font-size: 0.8em; }
    .toc-level-6 .toc-text { font-size: 0.75em; }

    .pdf-page {
      page-break-before: always;
      margin-bottom: 30px;
      width: 100%;
    }

    .pdf-page:first-child {
      page-break-before: auto;
    }

    .page-title {
      margin-top: 0;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 2px solid #333;
      color: #333;
      font-size: 1.8em;
    }
  </style>
</head>
<body>
  <div class="pdf-header">
    ${n.headerHTML||`<h1>${l}</h1>
    <p>${a}</p>
    <p>Generiert am: ${new Date().toLocaleString("de-DE")}</p>`}
  </div>
  ${c}
  <div class="pdf-content">${o}</div>
</body>
</html>`}async function ee(i,t={},l="report.pdf"){let n;n="https://elastotool-pdf-server-126717118048.europe-west3.run.app",n="http://localhost:8000";const a=await fetch(`${n}/generate-pdf`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({html:i,options:{...Qt,...t}})});if(!a.ok){const o=await a.text();throw new Error(`PDF generation failed: ${a.statusText} - ${o}`)}const e=await a.blob();if(!e.size)throw new Error("PDF returned empty file");return e}function ae(i,t){const l=URL.createObjectURL(i),n=document.createElement("a");n.href=l,n.download=t,document.body.appendChild(n),n.click(),URL.revokeObjectURL(l),n.remove()}function le(i,t,l="Brückenlager-Eingabeparameter",n="Berechnete Elastomer-Parameter"){const a=[];return i.forEach((e,o)=>{var b,v;const c=t[o],r=o+2;a.push({id:`page-${o+1}`,text:e.title||`Component ${o+1}`,level:1,originalTag:"h1",pageNumber:r}),(e.component.name==="PDFElastoParams"||(b=e.title)!=null&&b.includes("Elastomer-Parameter")||(v=e.title)!=null&&v.includes("Elastomer Parameters"))&&(a.push({id:"input-params",text:l,level:2,originalTag:"h3",pageNumber:r}),a.push({id:"calculated-params",text:n,level:2,originalTag:"h3",pageNumber:r})),_t(c.html).forEach(u=>{u.level>1&&u.id!=="input-params"&&u.id!=="calculated-params"&&a.push({id:`page-${o+1}-${u.id}`,text:u.text,level:Math.min(u.level+1,6),originalTag:u.originalTag,pageNumber:r})})}),a}async function be(i,t="multi-report",l={},n="statiqs Multi-Component Report",a){const{html:e,styles:o,pageInfo:c}=await Zt(i);let r;l.includeTableOfContents&&(r=le(i,c,l.inputParamsSectionTitle,l.calculatedParamsSectionTitle));const g=te(e,o,n,{includeTableOfContents:l.includeTableOfContents,tocTitle:l.tocTitle||"Inhaltsverzeichnis",customTocEntries:r,headerHTML:a,calculationReportSubtitle:l.calculationReportSubtitle}),b=await ee(g,l,`${t}.pdf`);ae(b,`${t}.pdf`)}export{ct as F,qt as T,fe as a,be as c};
