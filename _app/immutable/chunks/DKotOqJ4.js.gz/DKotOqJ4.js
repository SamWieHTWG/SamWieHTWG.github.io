import{R as o}from"./CYgJF_JY.js";import"./B17Q6ahh.js";function n(r,t){throw new o(r,t.toString())}export{n as r};
