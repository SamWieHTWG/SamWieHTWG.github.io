import{x as a}from"./DJ282x0m.js";a();
