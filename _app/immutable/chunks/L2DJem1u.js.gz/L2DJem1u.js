import{B as a}from"./Cqp8bxVM.js";a();
