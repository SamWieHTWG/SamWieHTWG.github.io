import{R as o,H as e}from"./CYgJF_JY.js";import"./B1V--xDm.js";function a(r,t){throw new e(r,t)}function c(r,t){throw new o(r,t.toString())}export{a as e,c as r};
