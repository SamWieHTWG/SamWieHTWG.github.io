import{h as r,f as c,b as s,E as i,a as h,p,c as d}from"./Cl0ug4r9.js";function u(f,t,o){r&&c();var n=f,a,e;s(()=>{a!==(a=t())&&(e&&(p(e),e=null),a&&(e=h(()=>o(n,a))))},i),r&&(n=d)}export{u as c};
