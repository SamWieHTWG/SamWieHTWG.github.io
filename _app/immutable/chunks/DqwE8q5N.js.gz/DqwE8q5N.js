import{a0 as a}from"./BWTM1ot2.js";a();
