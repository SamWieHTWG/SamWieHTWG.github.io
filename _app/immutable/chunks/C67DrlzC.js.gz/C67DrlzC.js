import{B as a}from"./BdERSUDM.js";a();
