import"./CWj6FrbW.js";import"./2x_3pxqx.js";import{u as S,ac as h,x as E,r as bt,ad as xt,F as st,G as Y,y as vt,z as k,A as C,v as J,C as ut,B as A,m as N,o as T,ae as O,af as M,k as F,ag as yt,Y as mt,ab as _t,ah as Tt}from"./95-tTr9P.js";import{l as $,p as w,i as B,s as wt}from"./DIGU72wg.js";import{a as X,C as Z,i as ht,b as j,s as gt}from"./Cg3LIffo.js";import{F as ct}from"./DcI0q6nk.js";import{b as Et,s as q,G as Pt,R as kt,a as K}from"./Bw086dH9.js";import{c as ft}from"./DuOoQ1F7.js";import{b as g,C as Ct,s as St}from"./989zpzj5.js";import{_ as Lt}from"./Dp1pzeXC.js";var Ht=S("<span></span>");function zt(i,t){const a=$(t,["children","$$slots","$$events","$$legacy"]),n=$(a,["size"]);let l=w(t,"size",8,"default");var e=Ht();X(e,o=>({...n,[Z]:o}),[()=>({"bx--tag":!0,"bx--tag--sm":l()==="sm","bx--skeleton":!0})]),h("click",e,function(o){g.call(this,t,o)}),h("mouseover",e,function(o){g.call(this,t,o)}),h("mouseenter",e,function(o){g.call(this,t,o)}),h("mouseleave",e,function(o){g.call(this,t,o)}),E(i,e)}var Rt=S("<span> </span>"),Mt=S('<div><!> <button type="button"><!></button></div>'),Ft=S("<div><!></div>"),At=S("<button><!> <span><!></span></button>"),Dt=S("<div><!></div>"),Nt=S("<div><!> <span><!></span></div>");function Bt(i,t){const a=Et(t),n=$(t,["children","$$slots","$$events","$$legacy"]),l=$(n,["type","size","filter","disabled","interactive","skeleton","title","icon","id"]);bt(t,!1);let e=w(t,"type",8,void 0),o=w(t,"size",8,"default"),c=w(t,"filter",8,!1),r=w(t,"disabled",8,!1),f=w(t,"interactive",8,!1),v=w(t,"skeleton",8,!1),b=w(t,"title",8,"Clear filter"),u=w(t,"icon",8,void 0),y=w(t,"id",24,()=>"ccs-"+Math.random().toString(36));const D=xt();ht();var Q=st(),dt=Y(Q);{var V=L=>{zt(L,wt({get size(){return o()}},()=>l,{$$events:{click(P){g.call(this,t,P)},mouseover(P){g.call(this,t,P)},mouseenter(P){g.call(this,t,P)},mouseleave(P){g.call(this,t,P)}}}))},W=(L,P)=>{{var tt=R=>{var p=Mt();X(p,s=>({"aria-label":b(),id:y(),...l,[Z]:s}),[()=>({"bx--tag":!0,"bx--tag--disabled":r(),"bx--tag--filter":c(),"bx--tag--sm":o()==="sm","bx--tag--red":e()==="red","bx--tag--magenta":e()==="magenta","bx--tag--purple":e()==="purple","bx--tag--blue":e()==="blue","bx--tag--cyan":e()==="cyan","bx--tag--teal":e()==="teal","bx--tag--green":e()==="green","bx--tag--gray":e()==="gray","bx--tag--cool-gray":e()==="cool-gray","bx--tag--warm-gray":e()==="warm-gray","bx--tag--high-contrast":e()==="high-contrast","bx--tag--outline":e()==="outline"})]);var H=k(p);q(H,t,"default",{props:{class:"bx--tag__label"}},s=>{var _=Rt();j(_,1,"",null,{},{"bx--tag__label":!0});var G=k(_,!0);C(_),J(()=>ut(G,e())),E(s,_)});var m=A(H,2);j(m,1,"",null,{},{"bx--tag__close-icon":!0});var x=k(m);Ct(x,{}),C(m),C(p),J(()=>{gt(m,"aria-labelledby",y()),m.disabled=r(),gt(m,"title",b())}),h("click",m,function(s){g.call(this,t,s)}),h("click",m,St(()=>{D("close")})),h("mouseover",m,function(s){g.call(this,t,s)}),h("mouseenter",m,function(s){g.call(this,t,s)}),h("mouseleave",m,function(s){g.call(this,t,s)}),E(R,p)},et=(R,p)=>{{var H=x=>{var s=At();X(s,d=>({type:"button",id:y(),disabled:r(),"aria-disabled":r(),tabindex:r()?"-1":void 0,...l,[Z]:d}),[()=>({"bx--tag":!0,"bx--tag--interactive":!0,"bx--tag--disabled":r(),"bx--tag--sm":o()==="sm","bx--tag--red":e()==="red","bx--tag--magenta":e()==="magenta","bx--tag--purple":e()==="purple","bx--tag--blue":e()==="blue","bx--tag--cyan":e()==="cyan","bx--tag--teal":e()==="teal","bx--tag--green":e()==="green","bx--tag--gray":e()==="gray","bx--tag--cool-gray":e()==="cool-gray","bx--tag--warm-gray":e()==="warm-gray","bx--tag--high-contrast":e()==="high-contrast","bx--tag--outline":e()==="outline"})]);var _=k(s);{var G=d=>{var z=Ft();j(z,1,"",null,{},{"bx--tag__custom-icon":!0});var lt=k(z);q(lt,t,"icon",{},nt=>{var U=st(),ot=Y(U);ft(ot,u,(rt,it)=>{it(rt,{})}),E(nt,U)}),C(z),E(d,z)};B(_,d=>{(a.icon||u())&&d(G)})}var I=A(_,2),at=k(I);q(at,t,"default",{},null),C(I),C(s),h("click",s,function(d){g.call(this,t,d)}),h("mouseover",s,function(d){g.call(this,t,d)}),h("mouseenter",s,function(d){g.call(this,t,d)}),h("mouseleave",s,function(d){g.call(this,t,d)}),E(x,s)},m=x=>{var s=Nt();X(s,d=>({id:y(),...l,[Z]:d}),[()=>({"bx--tag":!0,"bx--tag--disabled":r(),"bx--tag--sm":o()==="sm","bx--tag--red":e()==="red","bx--tag--magenta":e()==="magenta","bx--tag--purple":e()==="purple","bx--tag--blue":e()==="blue","bx--tag--cyan":e()==="cyan","bx--tag--teal":e()==="teal","bx--tag--green":e()==="green","bx--tag--gray":e()==="gray","bx--tag--cool-gray":e()==="cool-gray","bx--tag--warm-gray":e()==="warm-gray","bx--tag--high-contrast":e()==="high-contrast","bx--tag--outline":e()==="outline"})]);var _=k(s);{var G=d=>{var z=Dt();j(z,1,"",null,{},{"bx--tag__custom-icon":!0});var lt=k(z);q(lt,t,"icon",{},nt=>{var U=st(),ot=Y(U);ft(ot,u,(rt,it)=>{it(rt,{})}),E(nt,U)}),C(z),E(d,z)};B(_,d=>{(a.icon||u())&&d(G)})}var I=A(_,2),at=k(I);q(at,t,"default",{},null),C(I),C(s),h("click",s,function(d){g.call(this,t,d)}),h("mouseover",s,function(d){g.call(this,t,d)}),h("mouseenter",s,function(d){g.call(this,t,d)}),h("mouseleave",s,function(d){g.call(this,t,d)}),E(x,s)};B(R,x=>{f()?x(H):x(m,!1)},p)}};B(L,R=>{c()?R(tt):R(et,!1)},P)}};B(dt,L=>{v()?L(V):L(W,!1)})}E(i,Q),vt()}var Gt=S("<!> ",1),It=S("<div><!></div>"),Ut=S("<!> <!> <!> <!>",1);function se(i,t){bt(t,!1);const a=N(),n=N(),l=N();let e=w(t,"formula",8),o=w(t,"isFulfilled",8,null),c=w(t,"tagTextGood",8,null),r=w(t,"tagTextBad",8,null),f=w(t,"additionalSign1",8,""),v=N(),b=N(T(a)),u=N(!1);O(()=>M(e()),()=>{F(a,e().Result||"")}),O(()=>(M(c()),M(r())),()=>{F(n,c()!=null&&r()!=null)}),O(()=>M(o()),()=>{F(v,o()?"green":"red")}),O(()=>(M(o()),M(c()),M(r())),()=>{F(l,o()?c()||"":r()||"")}),O(()=>(T(a),T(b)),()=>{T(a)!==T(b)&&T(b)!==""&&(F(u,!0),setTimeout(()=>{F(u,!1)},500)),F(b,T(a))}),yt(),ht(),Pt(i,{fullWidth:!0,style:"padding: var(--cds-spacing-03);",children:(y,D)=>{kt(y,{noGutterRight:!0,padding:!1,children:(Q,dt)=>{var V=Ut(),W=Y(V);K(W,{noGutterRight:!0,sm:2,md:2,lg:2,children:(p,H)=>{ct(p,{padding:0,get formula(){return e().Name}})},$$slots:{default:!0}});var L=A(W,2);K(L,{noGutterRight:!0,sm:2,md:2,lg:7,children:(p,H)=>{var m=Gt(),x=Y(m);ct(x,{get formula(){return e().Abstract}});var s=A(x);J(()=>ut(s,` ${f()??""}`)),E(p,m)},$$slots:{default:!0}});var P=A(L,2);const tt=mt(()=>T(n)?3:7);K(P,{noGutterRight:!0,sm:2,md:2,get lg(){return T(tt)},children:(p,H)=>{var m=It();let x;var s=k(m);ct(s,{get formula(){return T(a)}}),C(m),J(_=>x=j(m,1,"svelte-u1m8dl",null,x,_),[()=>({highlighted:T(u)})],mt),E(p,m)},$$slots:{default:!0}});var et=A(P,2);{var R=p=>{K(p,{sm:2,md:2,lg:4,children:(H,m)=>{Bt(H,{get type(){return T(v)},get title(){return T(l)},style:"margin-top: -3px;",children:(x,s)=>{_t();var _=Tt();J(()=>ut(_,T(l))),E(x,_)},$$slots:{default:!0}})},$$slots:{default:!0}})};B(et,p=>{T(n)&&p(R)})}E(Q,V)},$$slots:{default:!0}})},$$slots:{default:!0}}),vt()}const Ot={format:"A4",margin:{top:"20mm",bottom:"20mm",left:"15mm",right:"15mm"},printBackground:!0,displayHeaderFooter:!1,landscape:!1,scale:1};function pt(i){const t=document.createElement("div");t.innerHTML=i;const a=[];return t.querySelectorAll("h1, h2, h3, h4, h5, h6").forEach((l,e)=>{var f;const o=parseInt(l.tagName.charAt(1)),c=((f=l.textContent)==null?void 0:f.trim())||"";let r=l.id;r||(r=`heading-${e+1}`,l.id=r),c&&a.push({id:r,text:c,level:o,originalTag:l.tagName.toLowerCase()})}),t.innerHTML="",a}function qt(i,t="Inhaltsverzeichnis"){if(i.length===0)return"";let a=`<div class="table-of-contents">
    <h2 class="toc-title">${t}</h2>
    <nav class="toc-nav">`,n=0;i.forEach((l,e)=>{if(l.level>n)for(let c=n;c<l.level;c++)a+='<ul class="toc-list">';else if(l.level<n)for(let c=l.level;c<n;c++)a+="</ul>";const o=l.pageNumber!==void 0?l.pageNumber.toString():"...";a+=`<li class="toc-item toc-level-${l.level}">
      <a href="#${l.id}" class="toc-link">
        <span class="toc-text">${l.text}</span>
        <span class="toc-dots"></span>
        <span class="toc-page-number">${o}</span>
      </a>
    </li>`,n=l.level});for(let l=0;l<n;l++)a+="</ul>";return a+="</nav></div>",a}function jt(){const i=[];for(const t of Array.from(document.styleSheets))try{const a=t.cssRules||t.rules;a&&Array.from(a).forEach(n=>n.cssText&&i.push(n.cssText))}catch{t.href&&i.push(`@import url("${t.href}");`)}return document.querySelectorAll("style").forEach(t=>t.textContent&&i.push(t.textContent)),i.join(`
`)}async function Yt(i,t={}){const a=document.createElement("div");a.style.position="absolute",a.style.left="-9999px",a.style.top="-9999px",a.style.visibility="hidden",document.body.appendChild(a);try{const{mount:n,unmount:l}=await Lt(async()=>{const{mount:u,unmount:y}=await import("./95-tTr9P.js").then(D=>D.bg);return{mount:u,unmount:y}},[],import.meta.url);await document.fonts.ready;const e=n(i,{target:a,props:t});await new Promise(u=>setTimeout(u,100));let o="",c=0;const r=20;for(let u=0;u<r;u++){const y=a.innerHTML;if(y===o){if(c++,c>=3)break}else c=0;o=y,await new Promise(D=>setTimeout(D,200))}const f=a.querySelectorAll("img");f.length>0&&await Promise.all(Array.from(f).map(u=>u.complete?Promise.resolve():new Promise(y=>{u.addEventListener("load",y),u.addEventListener("error",y),setTimeout(y,3e3)})));const v=a.innerHTML;if(l(e),!v.trim())throw new Error("Component rendered empty HTML");const b=jt();return{html:v,styles:b}}finally{a.remove()}}async function Jt(i){const t=[];let a="",n="";for(const[l,e]of i.entries()){const{component:o,props:c={},title:r=`Page ${l+1}`}=e,{html:f,styles:v}=await Yt(o,c),b=r?`<div class="pdf-page">
           <h1 class="page-title" id="page-${l+1}">${r}</h1>
           ${f}
         </div>`:`<div class="pdf-page" id="page-${l+1}">${f}</div>`;t.push({title:r,html:b}),a+=b,l===0&&(n=v)}return{html:a,styles:n,pageInfo:t}}function Qt(i){const t=window.location.origin;let a=i.replace(/url\(['"]?\/(fonts\/[^'"()]+)['"]?\)/g,`url('${t}/$1')`);return a+=`
    /* Fallback font rules for PDF generation */
    body, html, * {
      font-family: 'Quicksand', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif !important;
    }
  `,a}function Vt(i,t,a="Report",n={}){const l=n.calculationReportSubtitle||"Berechnungsbericht",e=Qt(t);let o=i,c="";if(n.includeTableOfContents){const r=n.customTocEntries||pt(i);if(r.length>0&&(c=qt(r,n.tocTitle),!n.customTocEntries)){const f=document.createElement("div");f.innerHTML=i,r.forEach(v=>{const b=f.querySelector(`#${v.id}`);b&&!b.id&&(b.id=v.id)}),o=f.innerHTML}}return`<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <title>${a}</title>
  <style>
    ${e}
    html, body { margin:0; padding:0; width:100%; background:white; }
    .pdf-header { text-align:center; margin-bottom:20px; }
    .pdf-content { width:100%; margin:8px; }
    button { display:none; }

    .table-of-contents {
      margin: 30px 0;
      padding: 20px 0;
      page-break-after: always;
    }

    .toc-title {
      margin: 0 0 20px 0;
      padding-bottom: 10px;
      border-bottom: 2px solid #333;
      font-size: 1.5em;
      color: #333;
    }

    .toc-nav {
      margin: 0;
    }

    .toc-list {
      list-style: none;
      margin: 0;
      padding: 0;
    }

    .toc-item {
      margin: 8px 0;
      line-height: 1.4;
    }

    .toc-link {
      display: flex;
      text-decoration: none;
      color: #333;
      padding: 4px 0;
      align-items: baseline;
    }

    .toc-link:hover {
      color: #0066cc;
    }

    .toc-text {
      flex-shrink: 0;
      margin-right: 8px;
    }

    .toc-dots {
      flex-grow: 1;
      border-bottom: 1px dotted #666;
      margin: 0 8px;
      height: 1px;
      margin-bottom: 4px;
    }

    .toc-page-number {
      flex-shrink: 0;
      font-style: italic;
      color: #666;
      min-width: 30px;
      text-align: right;
      font-weight: 500;
    }

    .toc-level-1 { margin-left: 0; }
    .toc-level-2 { margin-left: 20px; }
    .toc-level-3 { margin-left: 40px; }
    .toc-level-4 { margin-left: 60px; }
    .toc-level-5 { margin-left: 80px; }
    .toc-level-6 { margin-left: 100px; }

    .toc-level-2 .toc-text { font-size: 0.95em; }
    .toc-level-3 .toc-text { font-size: 0.9em; }
    .toc-level-4 .toc-text { font-size: 0.85em; }
    .toc-level-5 .toc-text { font-size: 0.8em; }
    .toc-level-6 .toc-text { font-size: 0.75em; }

    .pdf-page {
      page-break-before: always;
      margin-bottom: 30px;
      width: 100%;
    }

    .pdf-page:first-child {
      page-break-before: auto;
    }

    .page-title {
      margin-top: 0;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 2px solid #333;
      color: #333;
      font-size: 1.8em;
    }
  </style>
</head>
<body>
  <div class="pdf-header">
    ${n.headerHTML||`<h1>${a}</h1>
    <p>${l}</p>
    <p>Generiert am: ${new Date().toLocaleString("de-DE")}</p>`}
  </div>
  ${c}
  <div class="pdf-content">${o}</div>
</body>
</html>`}async function Wt(i,t={},a="report.pdf"){let n;n="https://elastotool-pdf-server-126717118048.europe-west3.run.app";const l=await fetch(`${n}/generate-pdf`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({html:i,options:{...Ot,...t}})});if(!l.ok){const o=await l.text();throw new Error(`PDF generation failed: ${l.statusText} - ${o}`)}const e=await l.blob();if(!e.size)throw new Error("PDF returned empty file");return e}function Kt(i,t){const a=URL.createObjectURL(i),n=document.createElement("a");n.href=a,n.download=t,document.body.appendChild(n),n.click(),URL.revokeObjectURL(a),n.remove()}function Xt(i,t,a="Brückenlager-Eingabeparameter",n="Berechnete Elastomer-Parameter"){const l=[];return i.forEach((e,o)=>{var v,b;const c=t[o],r=o+2;l.push({id:`page-${o+1}`,text:e.title||`Component ${o+1}`,level:1,originalTag:"h1",pageNumber:r}),(e.component.name==="PDFElastoParams"||(v=e.title)!=null&&v.includes("Elastomer-Parameter")||(b=e.title)!=null&&b.includes("Elastomer Parameters"))&&(l.push({id:"input-params",text:a,level:2,originalTag:"h3",pageNumber:r}),l.push({id:"calculated-params",text:n,level:2,originalTag:"h3",pageNumber:r})),pt(c.html).forEach(u=>{u.level>1&&u.id!=="input-params"&&u.id!=="calculated-params"&&l.push({id:`page-${o+1}-${u.id}`,text:u.text,level:Math.min(u.level+1,6),originalTag:u.originalTag,pageNumber:r})})}),l}async function ce(i,t="multi-report",a={},n="statiqs Multi-Component Report",l){const{html:e,styles:o,pageInfo:c}=await Jt(i);let r;a.includeTableOfContents&&(r=Xt(i,c,a.inputParamsSectionTitle,a.calculatedParamsSectionTitle));const f=Vt(e,o,n,{includeTableOfContents:a.includeTableOfContents,tocTitle:a.tocTitle||"Inhaltsverzeichnis",customTocEntries:r,headerHTML:l,calculationReportSubtitle:a.calculationReportSubtitle}),v=await Wt(f,a,`${t}.pdf`);Kt(v,`${t}.pdf`)}export{se as F,Bt as T,ce as c};
