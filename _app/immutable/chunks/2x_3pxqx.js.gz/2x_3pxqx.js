import{q as a}from"./95-tTr9P.js";a();
